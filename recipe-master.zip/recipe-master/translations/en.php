<?php
/**
 * Recipe plugin for Craft CMS
 *
 * Recipe Translation
 *
 * @author    nystudio107
 * @copyright Copyright (c) 2016 nystudio107
 * @link      http://nystudio107.com
 * @package   Recipe
 * @since     1.0.0
 */

return array(
    'Translate me' => 'To this',
);
